primeiro treino:



Train Size:80161
Validation Size:17177
Test Size:17178


Segundo Treino:


Total of Pick Plans:236793
Total of Pick Plans with Occupied Nodes:117113
Total of Impossible Pick Plans with Occupied Nodes:0
Total of Place Plans:221188
Total of Place Plans with Occupied Nodes:101508
Total of Impossible Place Plans with Occupied Nodes:0
Total of Goals:457981
Total of Plans:457981