class ArrayDictionary:
    def __init__(self, words):
        self.words = words