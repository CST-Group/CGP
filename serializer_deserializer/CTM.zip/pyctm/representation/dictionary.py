

class Dictionary():

    def __init__(self, words={}, values={}, baseValues={}, signalValues={}) -> None:
        self.words = words
        self.values = values
        self.baseValues = baseValues
        self.signalValues = signalValues
