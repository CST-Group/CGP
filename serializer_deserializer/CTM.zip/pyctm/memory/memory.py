class Memory:

    def get_i(self) -> object:
        pass

    def get_name(self) -> str:
        pass

    def get_evaluation(self) -> float:
        pass

    def get_id(self) -> str:
        pass

    def set_i(self, i) -> None:
        pass

    def set_name(self, name) -> None:
        pass

    def set_evaluation(self, evaluation) -> None:
        pass

    def set_id(self, id) -> None:
        pass
