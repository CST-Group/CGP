import enum


class KDistributedMemoryBehavior(enum.Enum):
    TRIGGERED = 0,
    PULLED = 1
